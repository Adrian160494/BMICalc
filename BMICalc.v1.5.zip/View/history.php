<div class="navigation">
    <div class="row">
        <div class="col-md-4 col-xs-12" ng-repeat="item in dataToHistory">
            <div class="card">
                {{item.bmr}}
            </div>
        </div>
    </div>
</div>